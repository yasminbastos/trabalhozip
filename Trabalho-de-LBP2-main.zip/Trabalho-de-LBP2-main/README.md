<h2>Participantes</h2>

<dl>
  <dt><strong>Ana Clara Rodrigues Peres Marçal</strong> - SP3117499 | Ana Clara (anarod07)</dt>

  <dt><strong>Gabrielly Leite de Macedo</strong> - SP3115763 | Gaby Macedo (GabyyMacedo)</dt>

  <dt><strong>Maria Eduarda de Araujo Souza</strong> - SP3115895 | Duda Araújo (Sunieee9)</dt>

  <dt><strong>Mayara Matilde Cardoso de Freitas</strong> - SP3115178 | MayMay (MayMatilde)</dt>

  <dt><strong>Rafael Gomes Messias</strong> - SP3124819 | Rafa (Rafael0978)</dt>

  <dt><strong>Yasmin Catherinne Conceição Bastos</strong> - SP3116212 | Yasmin (yasminbastos)</dt>
</dl>
