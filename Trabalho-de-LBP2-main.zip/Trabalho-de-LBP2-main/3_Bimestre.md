<h2>Participantes</h2>

<dl>
  <dt><strong>Ana Clara Rodrigues Peres Marçal</strong> - SP3117499 | Ana Clara (anarod07)</dt>
  <dd>- Páginas de erro</dd>

  <dt><strong>Gabrielly Leite de Macedo</strong> - SP3115763 | Gaby Macedo (GabyyMacedo)</dt>
  <dd>- Banco de dados</dd>
  <dd>- Front-end</dd>

  <dt><strong>Maria Eduarda de Araujo Souza</strong> - SP3115895 | Duda Araújo (Sunieee9)</dt>
  <dd>- Páginas de perfil e erro</dd>
  <dd>- Front-end</dd>

  <dt><strong>Mayara Matilde Cardoso de Freitas</strong> - SP3115178 | MayMay (MayMatilde)</dt>
  <dd>- Design</dd>
  <dd>- Front-end</dd>

  <dt><strong>Rafael Gomes Messias</strong> - SP3124819 | Rafa (Rafael0978)</dt>
  <dd>- Logo</dd>
  <dd>- Página inicial</dd>

  <dt><strong>Yasmin Catherinne Conceição Bastos</strong> - SP3116212 | Yasmin (yasminbastos)</dt>
  <dd>- Sessão do login e do cadastro</dd>
  <dd>- Front-end</dd>
</dl>
